#include "tree.h"

void prettyEXP(EXP *e);
